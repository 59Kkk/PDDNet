import torch
import torch.nn as nn
import torch.utils.model_zoo as model_zoo
from torchvision.models.resnet import resnet50


class res(nn.Module):
    def __init__(self):
        super(res, self).__init__()
        self.model = resnet50(pretrained=False)
        for parma in self.model.parameters():
            parma.requires_grad = True
        self.model.fc = torch.nn.Sequential(torch.nn.Linear(2048, 4096),
                                           torch.nn.ReLU(),
                                           torch.nn.Dropout(p=0.5),
                                           torch.nn.Linear(4096, 4096),
                                           torch.nn.ReLU(),
                                           torch.nn.Dropout(p=0.5),
                                           torch.nn.Linear(4096,1))

    def forward(self, x):
        y = self.model(x)
        return y
