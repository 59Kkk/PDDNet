#-*- coding:utf-8 -*-

import os
import time
import torch
import datetime
import torch.nn as nn
from torchvision.utils import save_image
from utils import Logger, denorm, ImagePool, GaussianNoise
from models import Generator, Discriminator
from tqdm import *
from data_loader import InputFetcher
# import tensorflow as tf
# tf.compat.v1.disable_eager_execution()
from visdom import Visdom
from torchstat import stat
class Tester(object):
    def __init__(self, loaders, args):

        # data loader
        self.loaders = loaders
        
        # Model configuration.
        self.args = args
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        # Directories.
        self.model_save_path = os.path.join(args.save_root_dir, args.version, args.model_save_path)
        self.sample_path = os.path.join(args.save_root_dir, args.version, args.sample_path)
        self.log_path = os.path.join(args.save_root_dir, args.version, args.log_path)
        self.test_result_path = os.path.join(args.save_root_dir, args.version, args.test_result_path)

        # Build the model and tensorboard.
        self.build_model()
        if self.args.use_tensorboard:
            self.build_tensorboard()

        
    def test(self):

        """ Test UEGAN ."""
        viz = Visdom(env='res')
        self.load_pretrained_model(self.args.pretrained_model)
        start_time = time.time()
        test_start = 0
        test_total_steps = len(self.loaders.tes)
        self.fetcher_test = InputFetcher(self.loaders.tes)

        test = {}
        test_save_path = self.test_result_path + '/' + 'test_results'
        test_compare_save_path = self.test_result_path + '/' + 'test_compare'

        if not os.path.exists(test_save_path):
            os.makedirs(test_save_path)
        if not os.path.exists(test_compare_save_path):
            os.makedirs(test_compare_save_path)

        self.G.eval()
        # stat(self.G,(3,512,512))

        pbar = tqdm(total=(test_total_steps - test_start), desc='Test epoches', position=test_start)
        pbar.write("============================== Start tesing ==============================")
        with torch.no_grad():
            for test_step in range(test_start, test_total_steps):
                input = next(self.fetcher_test)
                test_real_raw, test_name = input.img_raw, input.img_name

                # project_start = datetime.datetime.now()
                test_fake_exp = self.G(test_real_raw)
                # project_end = datetime.datetime.now()
                # print("Project Taking Time: %s" % (project_end - project_start))

                # test_fake_exp = denorm(test_fake_exp)
                # save_imgs1 = torch.squeeze(test_fake_exp)
                # _inputR = torch.tensor(save_imgs1[0, :, :])
                # _inputR = torch.unsqueeze(_inputR, 2)
                # _inputG = torch.tensor(save_imgs1[1, :, :])
                # _inputG = torch.unsqueeze(_inputG, 2)
                # _inputB = torch.tensor(save_imgs1[2, :, :])
                # _inputB = torch.unsqueeze(_inputB, 2)
                # _input = torch.cat([_inputR, _inputG, _inputB], dim=2)
                # _input = _input.cpu().numpy()
                # _input = tf.cast(_input * 255., tf.int32)
                # output = []
                # values_range = tf.constant([0, 255], dtype=tf.int32)
                # for i in range(3):
                #     image = tf.expand_dims(_input[:, :, i], -1)
                #     histogram = tf.histogram_fixed_width(image, values_range, 256)
                #     histogram = tf.cast(histogram, tf.float32)
                #     histogram = tf.compat.v1.log1p(histogram)
                #     histogram = histogram / tf.reduce_sum(histogram)
                #     cdf = tf.cumsum(histogram)  ###累加和
                #     px_map = tf.round(cdf * 255.)
                #     px_map = tf.cast(px_map, tf.int32)
                #     out = tf.expand_dims(tf.gather_nd(px_map, tf.cast(image, tf.int32)), 2)
                #     output.append(out)
                # final = tf.concat([output[0], output[1], output[2]], -1)
                # final = tf.cast(final, tf.float32) / 255.
                # session = tf.compat.v1.Session()
                # final = session.run(final)
                # finalR = torch.tensor(final[:, :, 0])
                # finalG = torch.tensor(final[:, :, 1])
                # finalB = torch.tensor(final[:, :, 2])
                # resR = torch.unsqueeze(finalR, 0)
                # resG = torch.unsqueeze(finalG, 0)
                # resB = torch.unsqueeze(finalB, 0)
                # final = torch.cat([resR, resG, resB], dim=0)
                # test_fake_exp = torch.unsqueeze(final, 0)

                for i in range(0, test_real_raw.data.size(0)):

                    save_imgs = test_fake_exp.data[i:i + 1, :, :, :]
                    # res = res.data[i:i + 1, :, :, :]
                    test_real_raw = denorm(test_real_raw).data[i:i + 1, :, :, :]
                    # save_image(save_imgs, os.path.join(test_save_path, '{:s}_{:0>3.2f}.png'.format(test_name[i], self.args.pretrained_model)))
                    save_image(save_imgs, os.path.join(test_save_path, '{:s}.jpg'.format(test_name[i])))

                    # viz.images(test_real_raw, win='raw', opts=dict(title='raw'))
                    # viz.images(save_imgs, win='result', opts=dict(title='result'))
                    # viz.images(res, win='res', opts=dict(title='res'))

                elapsed = time.time() - start_time
                elapsed = str(datetime.timedelta(seconds=elapsed))
                if test_step % self.args.info_step == 0:
                    pbar.write("=== Elapse:{}, Save {:>3d}-th test_fake_exp images into {} ===".format(elapsed, test_step, test_save_path))
                test['test/testFakeExp'] = test_fake_exp.detach().cpu()
                test['test_compare/testRealRaw_testFakeExp'] = torch.cat([test_real_raw.cpu(), test_fake_exp.detach().cpu()], 3)

                pbar.update(1)

                if self.args.use_tensorboard:
                    for tag, images in test.items():
                        self.logger.images_summary(tag, images, test_step + 1)



    """define some functions"""
    def build_model(self):
        """Create a generator and a discriminator."""
        self.G = Generator(self.args.g_conv_dim, self.args.g_norm_fun, self.args.g_act_fun, self.args.g_use_sn).to(self.device)
        self.D = Discriminator(self.args.d_conv_dim, self.args.d_norm_fun, self.args.d_act_fun, self.args.d_use_sn, self.args.adv_loss_type).to(self.device)
        if self.args.parallel:
            self.G.to(self.args.gpu_ids[0])
            self.D.to(self.args.gpu_ids[0])
            self.G = nn.DataParallel(self.G, self.args.gpu_ids)
            self.D = nn.DataParallel(self.D, self.args.gpu_ids)
        print("=== Models have been created ===")
        
        # print network
        if self.args.is_print_network:
            self.print_network(self.G, 'Generator')
            self.print_network(self.D, 'Discriminator')


    def print_network(self, model, name):
        """Print out the network information."""
        num_params = 0
        for p in model.parameters():
            num_params += p.numel()
        # print(model)
        print("=== The number of parameters of the above model [{}] is [{}] or [{:>.4f}M] ===".format(name, num_params, num_params / 1e6))


    def load_pretrained_model(self, resume_epochs):
        checkpoint_path = os.path.join(self.model_save_path, '{}_{}_{}.pth'.format(self.args.version, self.args.adv_loss_type, resume_epochs))
        if torch.cuda.is_available():
            # save on GPU, load on GPU
            checkpoint = torch.load(checkpoint_path)
            self.G.load_state_dict(checkpoint['G_net'])
            self.D.load_state_dict(checkpoint['D_net'])
        else:
            # save on GPU, load on CPU
            checkpoint = torch.load(checkpoint_path, map_location=lambda storage, loc: storage)
            self.G.load_state_dict(checkpoint['G_net'])
            self.D.load_state_dict(checkpoint['D_net'])

        print("=========== loaded trained models (epochs: {})! ===========".format(resume_epochs))


    def build_tensorboard(self):
        """Build a tensorboard logger."""
        self.logger = Logger(self.log_path)